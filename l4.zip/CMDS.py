z = """Available Commands
/rclone : This will change your drive config on fly.(First one will be default)
 
/gclone: This command is used to clone gdrive files or folder using gclone.
Syntax:- [ID of the file or folder][one space][name of your folder only(If the id is of file, don't put anything)] and then reply /gclone to it.
 
/log: This will send you a txt file of the logs.
 
/ytdl: This command should be used as reply to a supported link
 
/playlist: This command will download videos from youtube playlist link and will upload to telegram.
 
/gytdl: This will download and upload to your cloud.
 
/gpytdl: This download youtube playlist and upload to your cloud.
 
/leech: This command should be used as reply to a magnetic link, a torrent link, or a direct link. [this command will SPAM the chat and send the downloads a seperate files, if there is more than one file, in the specified torrent]
 
/archive: This command should be used as reply to a magnetic link, a torrent link, or a direct link. [This command will create a .tar.gz file of the output directory, and send the files in the chat, splited into PARTS of 1024MiB each, due to Telegram limitations]
 
/gleech: This command should be used as reply to a magnetic link, a torrent link, or a direct link. And this will download the files from the given link or torrent and will upload to the cloud using rclone.
 
/gleech_archive This command will compress the folder/file and will upload to your cloud.
 
/extract: This will unarchive file and upload to telegram.
 
/gleeche_extract: This will unarchive file and upload to cloud.
 
/tleech: This will mirror the telegram files to ur respective cloud .
 
/tleechunzip: This will unarchive telegram file and upload to cloud.
 
/getsize: This will give you total size of your destination folder in cloud.
 
/renewme: This will clear the remains of downloads which are not getting deleted after upload of the file or after /cancel command.
 
/cancel [GID]: To cancel ur download

/rename: To rename the telegram files.
 
Only work with direct link and youtube link for nowIt is like u can add custom name as prefix of the original file name. Like if your file name is gk.txt uploaded will be what u add in CUSTOM_FILE_NAME + gk.txt
 
Only works with direct link/youtube link.No magnet or torrent.
 
And also added custom name like...
 
You have to pass link as www.download.me/gk.txt | new.txt
 
the file will be uploaded as new.txt.
 
/savethumbnail: Reply To A Photo To Save As Custom Thumbnail

/clearthumbnail: To Clear Saved Custom Thumbnail

/togglevideo: To Upload Your Files As Streamable

/togglefile: To Upload Your Files As Documents

How to Use....?
Send any one of the available command, as a reply to a valid link/magnet/torrent. 👊

Current Custom Upload Mode: Document"""


z = z.replace(":", " -").split("\n")

cmds = []


for k in z:
    if k.startswith("/"):
        cmds.append(k)
        
zz = ""

for ss in cmds:
    zz = zz + ss.replace("/", "") + "\n"
    
print(zz)