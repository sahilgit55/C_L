from os.path import join as osjoin
from time import time
from shutil import copyfile


async def copy_file(input_file, output_dir):
    output_file = osjoin(output_dir, str(time()) + ".jpg")
    # https://stackoverflow.com/a/123212/4723940
    copyfile(input_file, output_file)
    return output_file