from asyncio import create_subprocess_exec
from asyncio.subprocess import PIPE
from os.path import isdir, exists
from os.path import join as osjoin
from os import makedirs
from time import time
from tobrot import DOWNLOAD_LOCATION


async def request_download(url, file_name, r_user_id):
    directory_path = osjoin(DOWNLOAD_LOCATION, str(r_user_id), str(time()))
    # create download directory, if not exist
    if not isdir(directory_path):
        makedirs(directory_path)
    local_file_path = osjoin(directory_path, file_name)
    command_to_exec = ["wget", "-O", local_file_path, url]
    process = await create_subprocess_exec(
        *command_to_exec,
        # stdout must a pipe to be accessible as process.stdout
        stdout=PIPE,
        stderr=PIPE,
    )
    # Wait for the subprocess to finish
    stdout, stderr = await process.communicate()
    e_response = stderr.decode().strip()
    # logger.info(e_response)
    t_response = stdout.decode().strip()
    # logger.info(t_response)
    final_m_r = e_response + "\n\n\n" + t_response
    if exists(local_file_path):
        return True, local_file_path
    else:
        return False, final_m_r
